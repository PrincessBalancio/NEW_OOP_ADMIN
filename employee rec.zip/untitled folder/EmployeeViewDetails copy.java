package com.example.ui;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.TitledBorder;

/**
 * EmployeeViewDetails (Read-Only Employee Info Display)
 */
public class EmployeeViewDetails extends JFrame {

    private JLabel[] labels; // all labels

    public EmployeeViewDetails(Object[] employeeData) {
        setTitle("Employee Details View");
        setSize(700, 900);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(250, 250, 252));
        setLayout(new BorderLayout());

        // --- Top Bar ---
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setOpaque(false);
        topBar.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        JLabel title = new JLabel("Employee Details");
        title.setFont(new Font("SansSerif", Font.BOLD, 18));

        JButton btnClose = new JButton("✕");
        btnClose.setPreferredSize(new Dimension(40, 32));
        btnClose.setFocusPainted(false);
        btnClose.setBorder(BorderFactory.createEmptyBorder());
        btnClose.setBackground(Color.WHITE);
        btnClose.addActionListener(e -> dispose());

        topBar.add(title, BorderLayout.WEST);
        topBar.add(btnClose, BorderLayout.EAST);
        add(topBar, BorderLayout.NORTH);

        // --- Form Container ---
        JPanel formContainer = new JPanel();
        formContainer.setLayout(new BoxLayout(formContainer, BoxLayout.Y_AXIS));
        formContainer.setBorder(BorderFactory.createEmptyBorder(8, 18, 18, 18));
        formContainer.setOpaque(false);

        labels = new JLabel[36];
        for (int i = 0; i < 36; i++) {
            labels[i] = new JLabel(employeeData[i] != null ? employeeData[i].toString() : "");
        }

        // --- Sections ---
        formContainer.add(createSection("Personal Information",
                new String[]{"ID", "Full Name", "Date of Birth", "Gender", "Nationality"},
                new JLabel[]{labels[0], labels[1], labels[2], labels[3], labels[4]}));

        formContainer.add(createSection("Contact Information",
                new String[]{"Address", "Phone", "Email"},
                new JLabel[]{labels[5], labels[6], labels[7]}));

        formContainer.add(createSection("Identification / Legal Information",
                new String[]{"SSS", "TIN", "PhilHealth", "Pag-IBIG", "Passport"},
                new JLabel[]{labels[8], labels[9], labels[10], labels[11], labels[12]}));

        formContainer.add(createSection("Job Details",
                new String[]{"Department", "Position", "Type", "Date Hired"},
                new JLabel[]{labels[13], labels[14], labels[15], labels[16], labels[17]}));

        formContainer.add(createSection("Compensation & Schedule",
                new String[]{"Salary", "Schedule", "Leave"},
                new JLabel[]{labels[18], labels[19], labels[20], labels[21]}));

        formContainer.add(createSection("Educational Background",
                new String[]{"Highest Degree", "School", "Year Graduated", "Certifications"},
                new JLabel[]{labels[22], labels[23], labels[24], labels[25]}));

        formContainer.add(createSection("Work History / Experience",
                new String[]{"Previous Employer", "Previous Position", "Years Experience"},
                new JLabel[]{labels[26], labels[27], labels[28], labels[29]}));

        formContainer.add(createSection("Health / Medical Information",
                new String[]{"Medical Conditions", "Blood Type", "HMO"},
                new JLabel[]{labels[30], labels[31], labels[32]}));

        formContainer.add(createSection("Emergency Contact",
                new String[]{"Name", "Relationship", "Phone"},
                new JLabel[]{labels[33], labels[34], labels[35]}));

        JScrollPane scrollPane = new JScrollPane(formContainer);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(new Color(250, 250, 252));
        add(scrollPane, BorderLayout.CENTER);
    }

    private JPanel createSection(String sectionTitle, String[] fieldNames, JLabel[] fieldLabels) {
        JPanel sectionPanel = new JPanel();
        sectionPanel.setLayout(new BoxLayout(sectionPanel, BoxLayout.Y_AXIS));
        sectionPanel.setBorder(BorderFactory.createTitledBorder(null, sectionTitle,
                TitledBorder.LEFT, TitledBorder.TOP,
                new Font("SansSerif", Font.BOLD, 14), new Color(50, 50, 50)));
        sectionPanel.setOpaque(false);
        sectionPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        for (int i = 0; i < fieldNames.length; i++) {
            JPanel fieldPanel = new JPanel(new BorderLayout());
            fieldPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
            fieldPanel.setBackground(new Color(240, 245, 250));
            fieldPanel.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));

            JLabel lblFieldName = new JLabel(fieldNames[i] + ": ");
            lblFieldName.setFont(new Font("SansSerif", Font.BOLD, 13));
            lblFieldName.setPreferredSize(new Dimension(150, 28));

            fieldLabels[i].setFont(new Font("SansSerif", Font.PLAIN, 13));

            fieldPanel.add(lblFieldName, BorderLayout.WEST);
            fieldPanel.add(fieldLabels[i], BorderLayout.CENTER);

            sectionPanel.add(fieldPanel);
            sectionPanel.add(Box.createRigidArea(new Dimension(0, 6)));
        }

        sectionPanel.add(Box.createRigidArea(new Dimension(0, 6)));
        return sectionPanel;
    }
}
