package com.example.ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.RowFilter;

public class Employee_Records extends JFrame {

    private JTable tableEmployees;
    public DefaultTableModel model;
    private int hoveredRow = -1;

    public Employee_Records() {
        setTitle("Employee Records");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        getContentPane().setBackground(new Color(249, 253, 255));
        getContentPane().setLayout(new BorderLayout());

        // ================== HEADER ==================
        JPanel header = new JPanel();
        header.setBackground(new Color(39, 56, 91));
        header.setPreferredSize(new Dimension(0, 64));
        header.setLayout(new BorderLayout());

        JPanel leftHeader = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 12));
        leftHeader.setOpaque(false);

        JLabel headerTitle = new JLabel("Employee Record and Management");
        headerTitle.setForeground(Color.WHITE);
        headerTitle.setFont(new Font("SansSerif", Font.BOLD, 26));
        leftHeader.add(headerTitle);

        JButton btnBack = styledMiniButton("BACK");
        btnBack.addActionListener(e -> dispose());
        leftHeader.add(btnBack);

        JPanel rightHeader = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 12));
        rightHeader.setOpaque(false);

        JButton btnAdd = styledMiniButton("ADD EMPLOYEE");
        btnAdd.addActionListener(e -> openEmployeeDetailsFormForCreate());
        rightHeader.add(btnAdd);

        header.add(leftHeader, BorderLayout.WEST);
        header.add(rightHeader, BorderLayout.EAST);

        getContentPane().add(header, BorderLayout.NORTH);

        // ================== MAIN PANEL ==================
        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(new Color(249, 253, 255));
        main.setBorder(BorderFactory.createEmptyBorder(12, 18, 18, 18));

        // TABS
        JPanel tabs = new JPanel(new BorderLayout());
        JPanel leftTab = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 6));
        leftTab.setOpaque(false);

        JLabel tabEmployees = new JLabel("Employees");
        tabEmployees.setFont(new Font("SansSerif", Font.BOLD, 14));
        tabEmployees.setBorder(
            BorderFactory.createMatteBorder(0, 0, 3, 0, new Color(66, 103, 178))
        );
        leftTab.add(tabEmployees);

        JPanel rightTab = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 6));
        rightTab.setOpaque(false);
        JButton btnArchive = styledMiniButton("Archive");
        JButton btnCalendar = styledMiniButton("Calendar");
        rightTab.add(btnArchive);
        rightTab.add(btnCalendar);

        tabs.add(leftTab, BorderLayout.WEST);
        tabs.add(rightTab, BorderLayout.EAST);
        main.add(tabs, BorderLayout.NORTH);

        // TABLE COLUMNS
        String[] columns = new String[]{
                "ID", "Name", "Department", "Position", "Salary",
                "Schedule", "Leave", "Type", "Status",
                "Edit", "View Details", "Archive"
        };

        model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return col >= 9;
            }
        };

        tableEmployees = new JTable(model);
        tableEmployees.setRowHeight(58);
        tableEmployees.setShowGrid(false);
        tableEmployees.setIntercellSpacing(new Dimension(0, 0));
        tableEmployees.getTableHeader().setReorderingAllowed(false);
        tableEmployees.getTableHeader().setPreferredSize(new Dimension(0, 42));
        tableEmployees.setFont(new Font("SansSerif", Font.PLAIN, 13));
        tableEmployees.getTableHeader().setDefaultRenderer(
            new HeaderRenderer(tableEmployees.getTableHeader().getDefaultRenderer())
        );
        tableEmployees.setDefaultRenderer(Object.class, new AlternatingRowRenderer());

        // ACTION BUTTON COLUMNS
        applyButtonColumn(9, "Edit");
        applyButtonColumn(10, "View Details");
        applyButtonColumn(11, "Archive");

        // FILTER
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 6));
        filterPanel.setOpaque(false);
        filterPanel.add(new JLabel("Filter by Type:"));
        JComboBox<String> cmbFilterType = new JComboBox<>(new String[]{"All", "Regular", "Part-time"});
        filterPanel.add(cmbFilterType);

        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
        tableEmployees.setRowSorter(sorter);

        cmbFilterType.addActionListener(e -> {
            String selected = (String) cmbFilterType.getSelectedItem();
            if ("All".equals(selected)) sorter.setRowFilter(null);
            else sorter.setRowFilter(RowFilter.regexFilter("^" + selected + "$", 7));
        });

        JScrollPane scroll = new JScrollPane(tableEmployees);
        scroll.setBorder(BorderFactory.createEmptyBorder());

        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(Color.WHITE);
        tablePanel.add(filterPanel, BorderLayout.NORTH);
        tablePanel.add(scroll, BorderLayout.CENTER);

        main.add(tablePanel, BorderLayout.CENTER);

        // ACTIONS
        // Archive top button: open archived UI (empty)
        btnArchive.addActionListener(e -> Archived_Employee.showUI());

        // Calendar top button: open calendar for currently selected employee (B)
        btnCalendar.addActionListener(e -> {
            int sel = tableEmployees.getSelectedRow();
            if (sel < 0) {
                JOptionPane.showMessageDialog(Employee_Records.this,
                    "Please select an employee row first to open that employee's calendar.",
                    "Select Employee", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            int modelRow = tableEmployees.convertRowIndexToModel(sel);
            Object idObj = model.getValueAt(modelRow, 0);
            String empId = idObj != null ? idObj.toString() : "IT00001";
            Calendar_Management.showUI(empId);
        });

        // HOVER EFFECTS
        tableEmployees.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseMoved(MouseEvent e) {
                int row = tableEmployees.rowAtPoint(e.getPoint());
                if (row != hoveredRow) {
                    hoveredRow = row;
                    tableEmployees.repaint();
                }
            }
        });
        tableEmployees.addMouseListener(new MouseAdapter() {
            public void mouseExited(MouseEvent e) {
                hoveredRow = -1;
                tableEmployees.repaint();
            }
        });

        // SAMPLE DATA
        model.addRow(new Object[]{
            "E001", "Alice Rivera", "HR", "Manager", "50000",
            "9am-6pm", "5", "Regular", "Active",
            "Edit", "View Details", "Archive"
        });

        model.addRow(new Object[]{
            "E002", "Ben Santos", "IT", "Developer", "45000",
            "10am-7pm", "3", "Part-time", "Active",
            "Edit", "View Details", "Archive"
        });

        getContentPane().add(main);
        setVisible(true);
    }

    // BUTTON STYLE
    private JButton styledMiniButton(String text) {
        JButton b = new JButton(text);
        b.setPreferredSize(new Dimension(130, 34));
        b.setFocusPainted(false);
        b.setBackground(new Color(180, 210, 255));
        b.setForeground(Color.BLACK);
        b.setFont(new Font("SansSerif", Font.PLAIN, 12));
        b.setBorder(new RoundedBorder());
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { b.setBackground(new Color(160, 195, 250)); }
            public void mouseExited(MouseEvent e) { b.setBackground(new Color(180, 210, 255)); }
        });
        return b;
    }

    private void applyButtonColumn(int index, String text) {
        TableColumn col = tableEmployees.getColumnModel().getColumn(index);
        col.setCellRenderer(new ModernActionRenderer(text));
        col.setCellEditor(new ModernActionEditor(text));
    }

    // HEADER RENDERER
    class HeaderRenderer implements TableCellRenderer {
        private final TableCellRenderer base;
        public HeaderRenderer(TableCellRenderer base) { this.base = base; }
        public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c) {
            Component cpt = base.getTableCellRendererComponent(t, v, s, f, r, c);
            cpt.setBackground(new Color(247,249,251));
            cpt.setForeground(new Color(80,80,90));
            cpt.setFont(new Font("SansSerif", Font.BOLD, 13));
            if (cpt instanceof JLabel) ((JLabel)cpt).setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
            return cpt;
        }
    }

    // ROW RENDERER
    class AlternatingRowRenderer extends DefaultTableCellRenderer {
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                       boolean hasFocus, int row, int column) {

            JLabel lbl = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            lbl.setOpaque(true);
            lbl.setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));

            if (isSelected) {
                lbl.setBackground(new Color(66, 103, 178));
                lbl.setForeground(Color.WHITE);
            } else if (row == hoveredRow) {
                lbl.setBackground(new Color(235, 245, 255));
                lbl.setForeground(Color.BLACK);
            } else {
                lbl.setBackground(row % 2 == 0 ? Color.WHITE : new Color(248, 250, 252));
                lbl.setForeground(Color.BLACK);
            }

            return lbl;
        }
    }

    // BUTTON RENDERER
    class ModernActionRenderer extends JButton implements TableCellRenderer {
        public ModernActionRenderer(String text) {
            setText(text);
            setFocusPainted(false);
            setOpaque(true);
            setBackground(new Color(180,210,255));
            setBorder(new RoundedBorder());
            setFont(new Font("SansSerif", Font.PLAIN, 11));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) { setBackground(new Color(160,195,250)); }
                public void mouseExited(MouseEvent e) { setBackground(new Color(180,210,255)); }
            });
        }
        public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c) {
            setText(v != null ? v.toString() : "");
            return this;
        }
    }

    // BUTTON EDITOR (UPDATED)
    class ModernActionEditor extends DefaultCellEditor {
        JButton btn;

        public ModernActionEditor(String text) {
            super(new JTextField());
            btn = new JButton(text);
            btn.setFocusPainted(false);
            btn.setBackground(new Color(180,210,255));
            btn.setBorder(new RoundedBorder());
            btn.setFont(new Font("SansSerif", Font.PLAIN, 11));
            btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

            btn.addActionListener(e -> {
                int row = tableEmployees.getSelectedRow();
                if (row < 0) return;

                int modelRow = tableEmployees.convertRowIndexToModel(row);
                int col = tableEmployees.getSelectedColumn();

                switch (col) {

                    case 9: // Edit
                        new EmployeeDetailsForm(model, modelRow).setVisible(true);
                        break;

                    case 10: // View Details (UPDATED TO SUPPORT 36 FIELDS)
                        Object[] fullData = new Object[36];

                        // Fill first 9 fields from table
                        for (int i = 0; i < 9; i++)
                            fullData[i] = model.getValueAt(modelRow, i);

                        // Remaining fields blank for now
                        for (int i = 9; i < 36; i++)
                            fullData[i] = "";

                        new EmployeeViewDetails(fullData).setVisible(true);
                        break;

                    case 11: // Archive
                        int confirm = JOptionPane.showConfirmDialog(Employee_Records.this,
                                "Archive this employee?", "Confirm", JOptionPane.YES_NO_OPTION);
                        if (confirm == JOptionPane.YES_OPTION) {
                            Object[] archivedData = new Object[model.getColumnCount()];
                            for (int i = 0; i < model.getColumnCount(); i++)
                                archivedData[i] = model.getValueAt(modelRow, i);

                            model.removeRow(modelRow);
                            Archived_Employee.addEmployeeToArchive(archivedData);
                        }
                        break;
                }
                fireEditingStopped();
            });
        }

        public Component getTableCellEditorComponent(JTable t, Object v, boolean s, int r, int c) {
            btn.setText(v != null ? v.toString() : "");
            return btn;
        }
    }

    class RoundedBorder extends javax.swing.border.AbstractBorder {
        public Insets getBorderInsets(Component c) { return new Insets(6, 12, 6, 12); }
        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            ((Graphics2D)g).drawRoundRect(x, y, w-1, h-1, 12, 12);
        }
    }

    private void openEmployeeDetailsFormForCreate() {
        new EmployeeDetailsForm(model, -1).setVisible(true);
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception e) {}
        SwingUtilities.invokeLater(Employee_Records::new);
    }
}
