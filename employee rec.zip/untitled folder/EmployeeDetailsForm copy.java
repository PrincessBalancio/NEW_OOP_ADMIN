package com.example.ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

public class EmployeeDetailsForm extends JFrame {

    // --- Personal Information ---
    private JTextField txtID, txtFullName, txtDOB, txtGender, txtNationality;
    // --- Contact Information ---
    private JTextField txtAddress, txtPhone, txtEmail;
    // --- Identification / Legal Info ---
    private JTextField txtSSS, txtTIN, txtPhilHealth, txtPagIBIG, txtPassport;
    // --- Job Details ---
    private JTextField txtDept, txtPos, txtDateHired, txtSupervisor;
    private JComboBox<String> cmbType;
    // --- Compensation & Schedule ---
    private JTextField txtSalary, txtSchedule, txtLeave, txtBankInfo;
    // --- Educational Background ---
    private JTextField txtHighestDegree, txtSchool, txtYearGrad, txtCertifications;
    // --- Work History / Experience ---
    private JTextField txtPrevEmployer, txtPrevPosition, txtYearsExperience, txtReasonLeaving;
    // --- Health / Medical Info ---
    private JTextField txtMedicalConditions, txtBloodType, txtHMO;
    // --- Emergency Contact ---
    private JTextField txtEmergencyName, txtEmergencyRelationship, txtEmergencyPhone;

    private DefaultTableModel model;
    private int editingRow;

    public EmployeeDetailsForm(DefaultTableModel model, int editingRow) {
        this.model = model;
        this.editingRow = editingRow;

        setTitle("Employee Details");
        setSize(650, 900);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(new Color(250, 250, 252));
        setLayout(new BorderLayout());

        // Top bar
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setOpaque(false);
        topBar.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        JLabel title = new JLabel(editingRow >= 0 ? "Edit Employee" : "Employee Details");
        title.setFont(new Font("SansSerif", Font.BOLD, 18));

        JButton btnClose = new JButton("✕");
        btnClose.setPreferredSize(new Dimension(40, 32));
        btnClose.setFocusPainted(false);
        btnClose.setBorder(BorderFactory.createEmptyBorder());
        btnClose.setBackground(Color.WHITE);
        btnClose.addActionListener(e -> dispose());

        topBar.add(title, BorderLayout.WEST);
        topBar.add(btnClose, BorderLayout.EAST);
        add(topBar, BorderLayout.NORTH);

        // Form container
        JPanel formContainer = new JPanel();
        formContainer.setLayout(new BoxLayout(formContainer, BoxLayout.Y_AXIS));
        formContainer.setBorder(BorderFactory.createEmptyBorder(8, 18, 18, 18));
        formContainer.setOpaque(false);

        // Personal Info Panel
        formContainer.add(makeGroupPanel("Personal Information",
            "ID", txtID = new JTextField(),
            "Full Name", txtFullName = new JTextField(),
            "Date of Birth (yyyy-mm-dd)", txtDOB = new JTextField(),
            "Gender", txtGender = new JTextField(),
            "Nationality", txtNationality = new JTextField()
        ));
        formContainer.add(Box.createRigidArea(new Dimension(0, 12)));

        // Contact Info Panel
        formContainer.add(makeGroupPanel("Contact Information",
            "Address", txtAddress = new JTextField(),
            "Phone Number", txtPhone = new JTextField(),
            "Email", txtEmail = new JTextField()
        ));
        formContainer.add(Box.createRigidArea(new Dimension(0, 12)));

        // Legal / IDs
        formContainer.add(makeGroupPanel("Identification / Legal Information",
            "SSS Number", txtSSS = new JTextField(),
            "TIN", txtTIN = new JTextField(),
            "PhilHealth", txtPhilHealth = new JTextField(),
            "Pag-IBIG", txtPagIBIG = new JTextField(),
            "Passport Number", txtPassport = new JTextField()
        ));
        formContainer.add(Box.createRigidArea(new Dimension(0, 12)));

        // Job Details
        formContainer.add(makeGroupPanel("Job Details",
            "Department", txtDept = new JTextField(),
            "Position", txtPos = new JTextField(),
            "Employee Type", cmbType = new JComboBox<>(new String[]{"Regular", "Part-time"}),
            "Date Hired (yyyy-mm-dd)", txtDateHired = new JTextField(),
            "Supervisor", txtSupervisor = new JTextField()
        ));
        formContainer.add(Box.createRigidArea(new Dimension(0, 12)));

        // Compensation & Schedule
        formContainer.add(makeGroupPanel("Compensation & Schedule",
            "Salary", txtSalary = new JTextField(),
            "Work Schedule", txtSchedule = new JTextField(),
            "Leaves Remaining", txtLeave = new JTextField(),
            "Bank Info", txtBankInfo = new JTextField()
        ));
        formContainer.add(Box.createRigidArea(new Dimension(0, 12)));

        // Educational Background
        formContainer.add(makeGroupPanel("Educational Background",
            "Highest Degree", txtHighestDegree = new JTextField(),
            "School / University", txtSchool = new JTextField(),
            "Year Graduated", txtYearGrad = new JTextField(),
            "Certifications / Skills", txtCertifications = new JTextField()
        ));
        formContainer.add(Box.createRigidArea(new Dimension(0, 12)));

        // Work History / Experience
        formContainer.add(makeGroupPanel("Work History / Experience",
            "Previous Employer", txtPrevEmployer = new JTextField(),
            "Position Held", txtPrevPosition = new JTextField(),
            "Years of Experience", txtYearsExperience = new JTextField(),
            "Reason Leaving", txtReasonLeaving = new JTextField()
        ));
        formContainer.add(Box.createRigidArea(new Dimension(0, 12)));

        // Health / Medical Info
        formContainer.add(makeGroupPanel("Health / Medical Information",
            "Medical Conditions / Allergies", txtMedicalConditions = new JTextField(),
            "Blood Type", txtBloodType = new JTextField(),
            "Health Insurance / HMO", txtHMO = new JTextField()
        ));
        formContainer.add(Box.createRigidArea(new Dimension(0, 12)));

        // Emergency Contact
        formContainer.add(makeGroupPanel("Emergency Contact",
            "Contact Name", txtEmergencyName = new JTextField(),
            "Relationship", txtEmergencyRelationship = new JTextField(),
            "Phone Number", txtEmergencyPhone = new JTextField()
        ));
        formContainer.add(Box.createRigidArea(new Dimension(0, 20)));

        // Buttons
        JButton btnSave = new JButton(editingRow >= 0 ? "Save" : "Create");
        btnSave.setPreferredSize(new Dimension(160, 36));
        btnSave.setBackground(new Color(66, 103, 178));
        btnSave.setForeground(Color.WHITE);
        btnSave.setFocusPainted(false);
        btnSave.addActionListener(e -> onSave());

        JButton btnCancel = new JButton("Cancel");
        btnCancel.setPreferredSize(new Dimension(120, 36));
        btnCancel.setFocusPainted(false);
        btnCancel.addActionListener(e -> dispose());

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.CENTER));
        actions.setOpaque(false);
        actions.add(btnSave);
        actions.add(Box.createRigidArea(new Dimension(8, 0)));
        actions.add(btnCancel);

        formContainer.add(actions);

        JScrollPane formScroll = new JScrollPane(formContainer);
        formScroll.setBorder(BorderFactory.createEmptyBorder());
        formScroll.getViewport().setBackground(new Color(250, 250, 252));
        add(formScroll, BorderLayout.CENTER);

        if (editingRow >= 0) populateFieldsFromModel(editingRow);
        else txtID.setText(generateNextID());
    }

    private JPanel makeGroupPanel(String title, Object... fields) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setOpaque(false);
        p.setBorder(BorderFactory.createTitledBorder(null, title,
            TitledBorder.LEFT, TitledBorder.TOP));

        for (int i = 0; i < fields.length; i += 2) {
            JLabel lbl = new JLabel(fields[i].toString());
            p.add(lbl);
            p.add(Box.createRigidArea(new Dimension(0, 6)));

            Component comp = (Component) fields[i + 1];
            comp.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
            p.add(comp);
            p.add(Box.createRigidArea(new Dimension(0, 10)));
        }
        return p;
    }

    private void populateFieldsFromModel(int row) {
        txtID.setText(getSafeValue(row, 0));
        txtFullName.setText(getSafeValue(row, 1));
        txtDOB.setText(getSafeValue(row, 2));
        txtGender.setText(getSafeValue(row, 3));
        txtNationality.setText(getSafeValue(row, 4));
        txtAddress.setText(getSafeValue(row, 5));
        txtPhone.setText(getSafeValue(row, 6));
        txtEmail.setText(getSafeValue(row, 7));
        txtSSS.setText(getSafeValue(row, 8));
        txtTIN.setText(getSafeValue(row, 9));
        txtPhilHealth.setText(getSafeValue(row, 10));
        txtPagIBIG.setText(getSafeValue(row, 11));
        txtPassport.setText(getSafeValue(row, 12));
        txtDept.setText(getSafeValue(row, 13));
        txtPos.setText(getSafeValue(row, 14));
        cmbType.setSelectedItem(getSafeValue(row, 15));
        txtDateHired.setText(getSafeValue(row, 16));
        txtSupervisor.setText(getSafeValue(row, 17));
        txtSalary.setText(getSafeValue(row, 18));
        txtSchedule.setText(getSafeValue(row, 19));
        txtLeave.setText(getSafeValue(row, 20));
        txtBankInfo.setText(getSafeValue(row, 21));
        txtHighestDegree.setText(getSafeValue(row, 22));
        txtSchool.setText(getSafeValue(row, 23));
        txtYearGrad.setText(getSafeValue(row, 24));
        txtCertifications.setText(getSafeValue(row, 25));
        txtPrevEmployer.setText(getSafeValue(row, 26));
        txtPrevPosition.setText(getSafeValue(row, 27));
        txtYearsExperience.setText(getSafeValue(row, 28));
        txtReasonLeaving.setText(getSafeValue(row, 29));
        txtMedicalConditions.setText(getSafeValue(row, 30));
        txtBloodType.setText(getSafeValue(row, 31));
        txtHMO.setText(getSafeValue(row, 32));
        txtEmergencyName.setText(getSafeValue(row, 33));
        txtEmergencyRelationship.setText(getSafeValue(row, 34));
        txtEmergencyPhone.setText(getSafeValue(row, 35));
    }

    private String getSafeValue(int row, int col) {
        if (col >= model.getColumnCount()) return "";
        Object o = model.getValueAt(row, col);
        return o == null ? "" : o.toString();
    }

    // --- Auto-increment ID
    private String generateNextID() {
        int next = 1;
        for (int i = 0; i < model.getRowCount(); i++) {
            Object val = model.getValueAt(i, 0);
            if (val != null && val.toString().matches("[A-Z]{2}\\d+")) {
                int num = Integer.parseInt(val.toString().substring(2));
                if (num >= next) next = num + 1;
            }
        }
        return String.format("IT%05d", next);
    }

    private void onSave() {
        if (txtFullName.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter Full Name.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Object[] rowData = new Object[]{
            txtID.getText(), txtFullName.getText(), txtDOB.getText(), txtGender.getText(), txtNationality.getText(),
            txtAddress.getText(), txtPhone.getText(), txtEmail.getText(),
            txtSSS.getText(), txtTIN.getText(), txtPhilHealth.getText(), txtPagIBIG.getText(), txtPassport.getText(),
            txtDept.getText(), txtPos.getText(), cmbType.getSelectedItem(), txtDateHired.getText(), txtSupervisor.getText(),
            txtSalary.getText(), txtSchedule.getText(), txtLeave.getText(), txtBankInfo.getText(),
            txtHighestDegree.getText(), txtSchool.getText(), txtYearGrad.getText(), txtCertifications.getText(),
            txtPrevEmployer.getText(), txtPrevPosition.getText(), txtYearsExperience.getText(), txtReasonLeaving.getText(),
            txtMedicalConditions.getText(), txtBloodType.getText(), txtHMO.getText(),
            txtEmergencyName.getText(), txtEmergencyRelationship.getText(), txtEmergencyPhone.getText()
        };

        if (editingRow >= 0) {
            // EDIT: Update all columns
            for (int i = 0; i < rowData.length; i++) {
                if (i < model.getColumnCount()) model.setValueAt(rowData[i], editingRow, i);
            }
        } else {
            // CREATE: Add new employee
            model.addRow(new Object[]{
                rowData[0], rowData[1], rowData[2], rowData[3], rowData[4],
                rowData[5], rowData[6], rowData[7], rowData[8], rowData[9],
                rowData[10], rowData[11], rowData[12], rowData[13], rowData[14],
                rowData[15], rowData[16], rowData[17], rowData[18], rowData[19],
                rowData[20], rowData[21], rowData[22], rowData[23], rowData[24],
                rowData[25], rowData[26], rowData[27], rowData[28], rowData[29],
                rowData[30], rowData[31], rowData[32], rowData[33], rowData[34],
                rowData[35], "Edit", "View Details", "Archive"
            });
        }

        dispose();
    }
}
