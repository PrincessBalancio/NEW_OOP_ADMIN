package com.example.ui;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.GroupLayout.Alignment;
import java.util.List;
import java.util.ArrayList;

public class Archived_Employee extends JFrame {

    private JTable tableEmployees;
    private DefaultTableModel model;

    // static storage (optional) so archives persist in memory while app runs
    private static List<Object[]> archivedList = new ArrayList<>();

    /**
     * Constructor.
     * @param employeeData if null => open empty Archived view (no rows).
     *                     if non-null => expected length >= 3 with indices:
     *                     [0]=ID, [1]=Name, [2]=Department, (others ignored)
     */
    public Archived_Employee(Object[] employeeData) {

        setTitle("Archived Employee Records");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); // FULL SCREEN
        getContentPane().setBackground(new Color(245, 247, 250));

        // COLUMNS -----------------------------------------
        String[] columns = {
            "ID", "Name", "Department", "Status"
        };

        model = new DefaultTableModel(columns, 0);

        // ADD HISTORY from static archivedList first
        for (Object[] row : archivedList) {
            if (row != null && row.length >= 3) {
                Object[] r = new Object[] {
                    row[0] != null ? row[0] : "",
                    row[1] != null ? row[1] : "",
                    row[2] != null ? row[2] : "",
                    "Inactive"
                };
                model.addRow(r);
            }
        }

        // ADD EMPLOYEE FROM Employee_Records (if provided)
        if (employeeData != null && employeeData.length >= 3) {
            Object[] row = new Object[]{
                employeeData[0] != null ? employeeData[0] : "",
                employeeData[1] != null ? employeeData[1] : "",
                employeeData[2] != null ? employeeData[2] : "",
                "Inactive"
            };
            model.addRow(row);
        }

        // TABLE -------------------------------------------
        tableEmployees = new JTable(model);
        tableEmployees.setRowHeight(30);
        tableEmployees.setShowGrid(true);
        tableEmployees.setGridColor(new Color(220, 220, 220));
        tableEmployees.setBackground(Color.WHITE);
        tableEmployees.setSelectionBackground(new Color(220, 235, 255));
        tableEmployees.setSelectionForeground(Color.BLACK);
        tableEmployees.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        // HEADER STYLE
        JTableHeader header = tableEmployees.getTableHeader();
        header.setBackground(new Color(50, 90, 160));
        header.setForeground(Color.WHITE);
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setReorderingAllowed(false);

        // STATUS column center alignment
        tableEmployees.getColumnModel().getColumn(3).setCellRenderer(new StatusBadgeRenderer());

        JScrollPane scroll = new JScrollPane(tableEmployees);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        scroll.getViewport().setBackground(Color.WHITE);

        // TOP HEADER PANEL --------------------------------
        JPanel panel = new JPanel();
        panel.setBackground(new Color(32, 47, 85));

        JLabel lblTitle = new JLabel("ARCHIVED EMPLOYEE RECORDS");
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));

        GroupLayout gl_panel = new GroupLayout(panel);
        gl_panel.setHorizontalGroup(
            gl_panel.createParallelGroup(Alignment.CENTER)
                .addGroup(gl_panel.createSequentialGroup()
                    .addGap(20)
                    .addComponent(lblTitle)
                    .addGap(20))
        );
        gl_panel.setVerticalGroup(
            gl_panel.createParallelGroup(Alignment.CENTER)
                .addGroup(gl_panel.createSequentialGroup()
                    .addGap(15)
                    .addComponent(lblTitle)
                    .addGap(15))
        );
        panel.setLayout(gl_panel);

        // BACK BUTTON -------------------------------------
        JButton btnBack = new JButton("BACK");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnBack.setFocusPainted(false);
        btnBack.setBackground(new Color(255, 255, 255));
        btnBack.setForeground(new Color(40, 65, 120));
        btnBack.setBorder(BorderFactory.createLineBorder(new Color(40, 65, 120), 2));

        btnBack.addActionListener(e -> dispose()); // close window

        // Hover animation
        btnBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnBack.setBackground(new Color(40, 65, 120));
                btnBack.setForeground(Color.WHITE);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnBack.setBackground(Color.WHITE);
                btnBack.setForeground(new Color(40, 65, 120));
            }
        });

        JPanel bottomSpace = new JPanel();
        bottomSpace.setBackground(new Color(245, 247, 250));

        GroupLayout gl_bottom = new GroupLayout(bottomSpace);
        gl_bottom.setHorizontalGroup(
            gl_bottom.createParallelGroup(Alignment.LEADING)
                .addGroup(gl_bottom.createSequentialGroup()
                    .addGap(20)
                    .addComponent(btnBack, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(20, Short.MAX_VALUE))
        );
        gl_bottom.setVerticalGroup(
            gl_bottom.createParallelGroup(Alignment.CENTER)
                .addGroup(gl_bottom.createSequentialGroup()
                    .addGap(10)
                    .addComponent(btnBack)
                    .addGap(10))
        );
        bottomSpace.setLayout(gl_bottom);

        // MAIN LAYOUT --------------------------------------
        GroupLayout groupLayout = new GroupLayout(getContentPane());
        groupLayout.setHorizontalGroup(
            groupLayout.createParallelGroup(Alignment.LEADING)
                .addGroup(groupLayout.createSequentialGroup()
                    .addGap(20)
                    .addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
                        .addComponent(panel)
                        .addComponent(scroll)
                        .addComponent(bottomSpace))
                    .addGap(20))
        );
        groupLayout.setVerticalGroup(
            groupLayout.createParallelGroup(Alignment.LEADING)
                .addGroup(groupLayout.createSequentialGroup()
                    .addGap(10)
                    .addComponent(panel, GroupLayout.PREFERRED_SIZE, 70, GroupLayout.PREFERRED_SIZE)
                    .addGap(20)
                    .addComponent(scroll)
                    .addGap(10)
                    .addComponent(bottomSpace, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
                )
        );

        getContentPane().setLayout(groupLayout);
    }

    // Static helper: show archived UI (no args)
    public static void showUI() {
        SwingUtilities.invokeLater(() -> new Archived_Employee(null).setVisible(true));
    }

    // Static helper: add to archive and open archived UI with this entry
    public static void addEmployeeToArchive(Object[] data) {
        if (data == null) return;
        archivedList.add(data);
        SwingUtilities.invokeLater(() -> new Archived_Employee(data).setVisible(true));
    }

    // STATUS BADGE RENDERER ------------------------------
    class StatusBadgeRenderer extends JLabel implements TableCellRenderer {

        public StatusBadgeRenderer() {
            setOpaque(true);
            setHorizontalAlignment(CENTER);
            setForeground(Color.WHITE);
            setFont(new Font("Segoe UI", Font.BOLD, 12));
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {

            setText(value != null ? value.toString() : "");
            setBackground(new Color(200, 50, 50)); // red badge

            if (isSelected) {
                setBackground(new Color(170, 30, 30));
            }
            return this;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Archived_Employee(null).setVisible(true));
    }
}
