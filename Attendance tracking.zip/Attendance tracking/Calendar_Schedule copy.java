package com.example.ui;

import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.time.*;
import java.time.format.TextStyle;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

public class Calendar_Schedule extends JFrame {

    private JPanel calendarGrid;
    private JLabel calendarTitle;
    private YearMonth currentMonth;
    private Map<String, Map<LocalDate, String>> employeeAttendance;
    private JTable employeeTable;
    private DefaultTableModel employeeTableModel;
    private String currentFilter = "All"; // Tracks selected status filter

    private static final Color PRESENT_BG = new Color(198, 239, 206); // light green
    private static final Color LATE_BG = new Color(255, 249, 196);    // light yellow
    private static final Color ABSENT_BG = new Color(255, 224, 230);  // light red
    private static final Color CARD_BORDER = new Color(225, 230, 235);

    private final String[][] employees = {
            {"Juan Dela Cruz", "IT00001"}
            // add more employees here
    };

    public Calendar_Schedule() {
        setTitle("Employee Attendance Calendar");
        setSize(1100, 700);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout());
        getContentPane().setBackground(Color.WHITE);

        currentMonth = YearMonth.now();

        // ---- header ----
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(26, 38, 67));
        header.setBorder(new MatteBorder(0, 0, 1, 0, new Color(210,210,210)));
        header.setPreferredSize(new Dimension(getWidth(), 120));

        JButton btnPrev = new JButton("◀");
        JButton btnNext = new JButton("▶");
        stylizeHeaderButton(btnPrev);
        stylizeHeaderButton(btnNext);

        JPanel topControls = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 10));
        topControls.setBackground(header.getBackground());
        topControls.add(btnPrev);

        calendarTitle = new JLabel();
        calendarTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        calendarTitle.setForeground(Color.WHITE);
        updateCalendarTitle();
        topControls.add(calendarTitle);

        topControls.add(btnNext);
        header.add(topControls, BorderLayout.NORTH);

        // Status legend panel below the month
        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 8));
        statusPanel.setBackground(header.getBackground());
        statusPanel.add(createStatusCard("All", Color.LIGHT_GRAY));
        statusPanel.add(createStatusCard("Present", PRESENT_BG));
        statusPanel.add(createStatusCard("Late", LATE_BG));
        statusPanel.add(createStatusCard("Absent", ABSENT_BG));
        header.add(statusPanel, BorderLayout.SOUTH);

        getContentPane().add(header, BorderLayout.NORTH);

        // ---- left employee table ----
        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setPreferredSize(new Dimension(260, getHeight()));
        leftPanel.setBackground(Color.WHITE);

        JLabel leftTitle = new JLabel("Employees");
        leftTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        leftTitle.setForeground(Color.BLACK);
        leftTitle.setBorder(new EmptyBorder(15, 15, 5, 5));
        leftPanel.add(leftTitle, BorderLayout.NORTH);

        employeeTableModel = new DefaultTableModel(new Object[]{"Employee (ID)"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        for (String[] emp : employees) {
            employeeTableModel.addRow(new Object[]{emp[0] + " (" + emp[1] + ")"});
        }

        employeeTable = new JTable(employeeTableModel);
        employeeTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        employeeTable.setForeground(Color.BLACK);
        employeeTable.setBackground(Color.WHITE);
        employeeTable.setRowHeight(30);
        employeeTable.setSelectionBackground(new Color(198, 239, 206));
        employeeTable.setSelectionForeground(Color.BLACK);
        employeeTable.setShowGrid(true);
        employeeTable.setGridColor(new Color(220,220,220));

        JTableHeader th = employeeTable.getTableHeader();
        th.setFont(new Font("Segoe UI", Font.BOLD, 14));
        th.setBackground(new Color(245,245,245));
        th.setForeground(Color.BLACK);

        JScrollPane scroll = new JScrollPane(employeeTable);
        scroll.setBorder(null);
        leftPanel.add(scroll, BorderLayout.CENTER);

        // Back button at bottom
        JButton btnBack = new JButton("Back");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnBack.setBackground(new Color(36, 60, 110));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnBack.setBorder(new EmptyBorder(8,12,8,12));
        btnBack.addActionListener(e -> dispose()); // closes this window
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 12));
        bottomPanel.setBackground(new Color(26, 38, 67));
        bottomPanel.add(btnBack);
        leftPanel.add(bottomPanel, BorderLayout.SOUTH);

        getContentPane().add(leftPanel, BorderLayout.WEST);

        // ---- calendar area ----
        JPanel calendarPanel = new JPanel(new BorderLayout());
        calendarPanel.setBackground(Color.WHITE);
        calendarPanel.setBorder(new EmptyBorder(16, 16, 16, 16));

        calendarGrid = new JPanel(new GridLayout(0, 7, 10, 10));
        calendarGrid.setBackground(Color.WHITE);
        calendarPanel.add(calendarGrid, BorderLayout.CENTER);
        getContentPane().add(calendarPanel, BorderLayout.CENTER);

        // listeners
        btnPrev.addActionListener(e -> { currentMonth = currentMonth.minusMonths(1); updateCalendarTitle(); generateCalendar(); });
        btnNext.addActionListener(e -> { currentMonth = currentMonth.plusMonths(1); updateCalendarTitle(); generateCalendar(); });

        employeeTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) generateCalendar();
            }
        });

        // sample data
        employeeAttendance = sampleAttendance();

        // select first employee by default
        if (employeeTable.getRowCount() > 0) employeeTable.setRowSelectionInterval(0,0);

        generateCalendar();
    }

    private JLabel createStatusCard(String text, Color color) {
        JLabel lbl = new JLabel(text, SwingConstants.CENTER);
        lbl.setOpaque(true);
        lbl.setBackground(color);
        lbl.setForeground(Color.BLACK);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lbl.setBorder(new LineBorder(Color.DARK_GRAY, 1, true));
        lbl.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lbl.setPreferredSize(new Dimension(90,30));
        lbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent e) {
                currentFilter = text;
                generateCalendar();
            }
        });
        return lbl;
    }

    private void generateCalendar() {
        calendarGrid.removeAll();

        String[] days = { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" };
        for (String d : days) {
            JLabel label = new JLabel(d, SwingConstants.CENTER);
            label.setFont(new Font("Segoe UI", Font.BOLD, 13));
            label.setBorder(new MatteBorder(0,0,1,0,new Color(230,230,230)));
            label.setOpaque(true);
            label.setBackground(new Color(250,250,250));
            calendarGrid.add(label);
        }

        YearMonth ym = currentMonth;
        int startOffset = (ym.atDay(1).getDayOfWeek().getValue() + 6) % 7;
        for (int i = 0; i < startOffset; i++) calendarGrid.add(createEmptyCell());

        String employee = getSelectedEmployee();
        Map<LocalDate, String> attendance = employeeAttendance.getOrDefault(employee, new HashMap<>());

        for (int day = 1; day <= ym.lengthOfMonth(); day++) {
            LocalDate date = ym.atDay(day);

            RoundedPanel dayCard = new RoundedPanel(12, Color.WHITE);
            dayCard.setLayout(new BorderLayout());
            dayCard.setBorder(new EmptyBorder(8, 8, 8, 8));

            JLabel lblDay = new JLabel(String.valueOf(day));
            lblDay.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            lblDay.setHorizontalAlignment(SwingConstants.RIGHT);
            dayCard.add(lblDay, BorderLayout.NORTH);

            if (attendance.containsKey(date)) {
                String status = attendance.get(date); 
                JLabel lblStatus = new JLabel(status, SwingConstants.CENTER);
                lblStatus.setOpaque(true);
                lblStatus.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                lblStatus.setBorder(new EmptyBorder(6, 6, 6, 6));

                // pastel colors and dim if not matching filter
                if (status.toLowerCase().startsWith("present")) {
                    lblStatus.setBackground(PRESENT_BG);
                    lblStatus.setForeground(new Color(30, 80, 40));
                } else if (status.toLowerCase().startsWith("late")) {
                    lblStatus.setBackground(LATE_BG);
                    lblStatus.setForeground(new Color(100, 90, 0));
                } else if (status.toLowerCase().startsWith("absent")) {
                    lblStatus.setBackground(ABSENT_BG);
                    lblStatus.setForeground(new Color(110, 20, 30));
                } else {
                    lblStatus.setBackground(new Color(245,245,245));
                    lblStatus.setForeground(Color.BLACK);
                }

                // filter logic
                if (!currentFilter.equals("All") && !status.toLowerCase().startsWith(currentFilter.toLowerCase())) {
                    lblStatus.setBackground(new Color(245,245,245));
                    lblStatus.setForeground(Color.LIGHT_GRAY);
                }

                dayCard.add(lblStatus, BorderLayout.CENTER);
            } else {
                dayCard.setBackground(new Color(250, 250, 250));
            }

            dayCard.setPreferredSize(new Dimension(100, 90));
            calendarGrid.add(dayCard);
        }

        int totalCells = startOffset + ym.lengthOfMonth();
        int trailing = (7 - (totalCells % 7)) % 7;
        for (int i = 0; i < trailing; i++) calendarGrid.add(createEmptyCell());

        calendarGrid.revalidate();
        calendarGrid.repaint();
    }

    private JPanel createEmptyCell() {
        RoundedPanel p = new RoundedPanel(12, new Color(255,255,255));
        p.setBorder(new EmptyBorder(10, 10, 10, 10));
        return p;
    }

    private String getSelectedEmployee() {
        int idx = employeeTable.getSelectedRow();
        if (idx < 0) return employees[0][0];
        return employees[idx][0];
    }

    private void stylizeHeaderButton(JButton btn) {
        btn.setFocusPainted(false);
        btn.setBorder(new EmptyBorder(6,10,6,10));
        btn.setBackground(new Color(36, 60, 110));
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) { btn.setBackground(new Color(54, 84, 160)); }
            public void mouseExited(java.awt.event.MouseEvent evt) { btn.setBackground(new Color(36, 60, 110)); }
        });
    }

    private void updateCalendarTitle() {
        calendarTitle.setText("Employee Attendance - "
                + currentMonth.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH)
                + " " + currentMonth.getYear());
    }

    static class RoundedPanel extends JPanel {
        private int arc;
        private Color bg;

        public RoundedPanel(int arc, Color bg) {
            this.arc = arc;
            this.bg = bg == null ? Color.WHITE : bg;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Shape r = new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-1, arc, arc);
            g2.setColor(bg);
            g2.fill(r);
            g2.setColor(CARD_BORDER);
            g2.draw(r);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    private static Map<String, Map<LocalDate, String>> sampleAttendance() {
        Map<String, Map<LocalDate, String>> map = new HashMap<>();
        YearMonth ym = YearMonth.now();
        String[] names = {"Juan Dela Cruz"};
        for (String n : names) {
            Map<LocalDate, String> m = new HashMap<>();
            for (int d = 1; d <= ym.lengthOfMonth(); d++) {
                LocalDate dt = ym.atDay(d);
                int r = new Random().nextInt(3);
                if (r == 0) m.put(dt, "Present 08:00-17:00");
                else if (r == 1) m.put(dt, "Late 09:15-17:00");
                else m.put(dt, "Absent");
            }
            map.put(n, m);
        }
        return map;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Calendar_Schedule().setVisible(true));
    }
}
