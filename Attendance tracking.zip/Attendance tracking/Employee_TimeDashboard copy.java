package com.example.ui;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class Employee_TimeDashboard extends JFrame {

    private CircularCard cardTotal, cardLate, cardAbs;
    private JScrollPane scroll;
    private JLabel lblClock, lblDayDate;

    private DefaultTableModel model;
    private JTable attendanceTable;

    private JButton btnTotalEmployees;

    // Store individual employee data
    private HashMap<String, int[]> employeeData = new HashMap<>();
    private int[] overallData = {40, 20, 15}; // totalHours, lateCount, absenceCount

    public Employee_TimeDashboard() {
        setTitle("Employee Time Dashboard");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(new BorderLayout());
        getContentPane().setBackground(Color.WHITE);

        // ================== SIDEBAR ==================
        JPanel sidebar = new JPanel(null);
        sidebar.setPreferredSize(new Dimension(220, 0));
        sidebar.setBackground(new Color(18, 32, 71)); // dark navy
        getContentPane().add(sidebar, BorderLayout.WEST);

        int startY = 50;
        JButton btnAttendance = createSidebarButton("Manual Attendance", startY);
        JButton btnCalendar = createSidebarButton("Calendar Schedule", startY + 60);
        sidebar.add(btnAttendance);
        sidebar.add(btnCalendar);

        // Make the buttons functional: open the respective frames
        btnAttendance.addActionListener(e -> {
            // Open Manual_Attendance UI
            SwingUtilities.invokeLater(() -> {
                try {
                    new Manual_Attendance().setVisible(true);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            });
        });

        btnCalendar.addActionListener(e -> {
            // Open Calendar_Schedule UI
            SwingUtilities.invokeLater(() -> {
                try {
                    new Calendar_Schedule().setVisible(true);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            });
        });

        JButton btnBack = createSidebarButton("Back", 0);
        sidebar.add(btnBack);
        sidebar.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                int sidebarHeight = sidebar.getHeight();
                btnBack.setBounds(20, sidebarHeight - 70, 180, 50);
            }
        });

        // ================== MAIN PANEL ==================
        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(Color.WHITE);
        getContentPane().add(mainPanel, BorderLayout.CENTER);

        JLabel lblHello = new JLabel("Hello Admin,");
        lblHello.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblHello.setBounds(20, 20, 500, 40);
        mainPanel.add(lblHello);

        JLabel lblWelcome = new JLabel("Welcome to your Employee Attendance Dashboard");
        lblWelcome.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblWelcome.setBounds(20, 65, 700, 20);
        mainPanel.add(lblWelcome);

        // CLOCK
        lblClock = new JLabel();
        lblClock.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        mainPanel.add(lblClock);

        lblDayDate = new JLabel();
        lblDayDate.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        mainPanel.add(lblDayDate);

        Timer timer = new Timer(1000, e -> updateClock());
        timer.start();

        // TOTAL EMPLOYEE BUTTON
        btnTotalEmployees = new JButton("Total Employees");
        btnTotalEmployees.setBounds(20, 95, 180, 35);
        btnTotalEmployees.setFocusPainted(false);
        btnTotalEmployees.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnTotalEmployees.setBackground(new Color(135, 206, 250));
        btnTotalEmployees.setBorder(new MatteBorder(1,1,1,1,Color.BLACK));
        btnTotalEmployees.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnTotalEmployees.addActionListener(e -> showOverallData());
        mainPanel.add(btnTotalEmployees);

        // ================== CARDS ==================
        cardTotal = new CircularCard("Total Hours Worked", overallData[0], 100, new Color(135, 206, 250));
        cardLate = new CircularCard("Number of Late Resumptions", overallData[1], 100, new Color(255, 165, 0));
        cardAbs = new CircularCard("Number of Absences", overallData[2], 100, new Color(255, 69, 0));

        mainPanel.add(cardTotal);
        mainPanel.add(cardLate);
        mainPanel.add(cardAbs);

        SwingUtilities.invokeLater(() -> {
            cardTotal.animate();
            cardLate.animate();
            cardAbs.animate();
        });

        // ================== TABLE ==================
        String[] colNames = {"Employee ID", "Name", "Date", "Time In", "Time Out", "Status"};
        Object[][] rowData = {
                {"EMP001", "John Cruz", "Nov 20", "8:00 AM", "5:00 PM", "Present"},
                {"EMP001", "John Cruz", "Nov 21", "8:15 AM", "5:03 PM", "Late"},
                {"EMP001", "John Cruz", "Nov 22", "--", "--", "Absent"},
                {"EMP002", "Mary Santos", "Nov 20", "8:05 AM", "5:00 PM", "Present"},
                {"EMP002", "Mary Santos", "Nov 21", "8:10 AM", "5:05 PM", "Late"},
                {"EMP002", "Mary Santos", "Nov 22", "--", "--", "Absent"}
        };

        // compute individual employee percentages
        computeEmployeeData(rowData);

        model = new DefaultTableModel(rowData, colNames) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        attendanceTable = new JTable(model) {
            @Override
            public Component prepareRenderer(TableCellRenderer renderer, int row, int col) {
                Component c = super.prepareRenderer(renderer, row, col);
                if (!isRowSelected(row)) {
                    c.setBackground(row % 2 == 0 ? new Color(245, 248, 255) : Color.WHITE);
                } else {
                    c.setBackground(new Color(173, 216, 230));
                }
                if (c instanceof JComponent) ((JComponent)c).setBorder(BorderFactory.createEmptyBorder(8,10,8,10));
                return c;
            }
        };

        attendanceTable.setRowHeight(38);
        attendanceTable.setShowHorizontalLines(false);
        attendanceTable.setShowVerticalLines(false);
        attendanceTable.setIntercellSpacing(new Dimension(0,0));
        attendanceTable.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        attendanceTable.setSelectionForeground(Color.BLACK);

        JTableHeader header = attendanceTable.getTableHeader();
        header.setPreferredSize(new Dimension(0,40));
        header.setFont(new Font("Segoe UI", Font.BOLD, 15));
        header.setOpaque(true);
        header.setBackground(new Color(220, 230, 245));
        header.setBorder(new MatteBorder(0,0,2,0,new Color(200,210,230)));

        scroll = new JScrollPane(attendanceTable);
        scroll.setBorder(new LineBorder(new Color(210,210,210),2,true));
        scroll.getViewport().setBackground(Color.WHITE);
        mainPanel.add(scroll);

        // Table selection listener
        attendanceTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && attendanceTable.getSelectedRow() >= 0) {
                int row = attendanceTable.getSelectedRow();
                String empId = (String) model.getValueAt(row, 0);
                showEmployeeData(empId);
            }
        });

        JLabel lblRecord = new JLabel("Attendance Record");
        lblRecord.setFont(new Font("Segoe UI", Font.BOLD, 16));
        mainPanel.add(lblRecord);

        // COMPONENT RESIZE
        mainPanel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                resizeComponents(mainPanel, lblRecord);
            }
        });

        // initial layout sizing (for first display)
        setSize(1200, 760);
        setLocationRelativeTo(null);
    }

    private void computeEmployeeData(Object[][] data) {
        for (Object[] row : data) {
            String empId = (String) row[0];
            int[] stats = employeeData.getOrDefault(empId, new int[3]); // total, late, abs
            stats[0]++; // total
            String status = (String) row[5];
            if ("Late".equals(status)) stats[1]++;
            if ("Absent".equals(status)) stats[2]++;
            employeeData.put(empId, stats);
        }
    }

    private void showEmployeeData(String empId) {
        if (employeeData.containsKey(empId)) {
            int[] stats = employeeData.get(empId);
            cardTotal.setValue(stats[0]);
            cardLate.setValue(stats[1]);
            cardAbs.setValue(stats[2]);
            cardTotal.animate();
            cardLate.animate();
            cardAbs.animate();
        }
    }

    private void showOverallData() {
        cardTotal.setValue(overallData[0]);
        cardLate.setValue(overallData[1]);
        cardAbs.setValue(overallData[2]);
        cardTotal.animate();
        cardLate.animate();
        cardAbs.animate();
    }

    private void updateClock() {
        Date now = new Date();
        lblClock.setText(new SimpleDateFormat("hh:mm:ss a").format(now));
        lblDayDate.setText(new SimpleDateFormat("EEEE, MMM dd yyyy").format(now));
    }

    private void resizeComponents(JPanel mainPanel, JLabel lblRecord) {
        int width = mainPanel.getWidth() - 40; // padding
        int gap = 20;
        int cardWidth = (width - 2 * gap) / 3;
        int cardHeight = 180;

        cardTotal.setBounds(20, 140, cardWidth, cardHeight);
        cardLate.setBounds(20 + cardWidth + gap, 140, cardWidth, cardHeight);
        cardAbs.setBounds(20 + (cardWidth + gap) * 2, 140, cardWidth, cardHeight);

        lblRecord.setBounds(20, 350, width, 30);
        scroll.setBounds(20, 380, width, mainPanel.getHeight() - 400);

        lblClock.setBounds(width - 180, 20, 160, 20);
        lblDayDate.setBounds(width - 180, 45, 160, 20);
    }

    // CircularCard class
    class CircularCard extends JPanel {
        private int value, maxValue = 100, currentValue = 0;
        private Color progressColor;
        private JLabel lblTitle;

        public CircularCard(String title, int value, int maxValue, Color progressColor) {
            this.value = value;
            this.maxValue = maxValue;
            this.progressColor = progressColor;
            setLayout(null);
            setBackground(Color.WHITE);
            setBorder(new MatteBorder(1,1,1,1,new Color(220,220,220)));

            lblTitle = new JLabel(title);
            lblTitle.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            lblTitle.setBounds(10, 10, 280, 20);
            add(lblTitle);
        }

        public void setValue(int value) {
            this.value = value;
        }

        public void animate() {
            currentValue = 0;
            Timer t = new Timer(12, null);
            t.addActionListener(e -> {
                if (currentValue < value) {
                    currentValue++;
                    repaint();
                } else {
                    ((Timer)e.getSource()).stop();
                }
            });
            t.start();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int padding = Math.max(20, getWidth() / 10);
            int size = Math.min(getWidth(), getHeight()) - padding * 2;
            size = Math.max(size, 50);
            int x = (getWidth() - size) / 2;
            int y = (getHeight() - size) / 2;

            g2.setStroke(new BasicStroke(size / 10f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2.setColor(new Color(230, 230, 230));
            g2.drawOval(x, y, size, size);

            float ratio = Math.min(1f, (float) currentValue / Math.max(1, maxValue));
            int angle = (int)(360f * ratio);
            g2.setColor(progressColor);
            g2.drawArc(x, y, size, size, 90, -angle);

            String vtext = currentValue + "%";
            g2.setFont(new Font("Segoe UI", Font.BOLD, size / 4));
            g2.setColor(Color.BLACK);
            FontMetrics fm = g2.getFontMetrics();
            int tx = x + size/2 - fm.stringWidth(vtext)/2;
            int ty = y + size/2 + fm.getAscent()/2;
            g2.drawString(vtext, tx, ty);
        }
    }

    private JButton createSidebarButton(String text, int yPos) {
        JButton btn = new JButton("<html><center>" + text + "</center></html>");
        btn.setBounds(20, yPos, 180, 50);
        btn.setFocusPainted(false);
        btn.setForeground(Color.WHITE);
        btn.setBackground(new Color(18, 32, 71));
        btn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btn.setBorderPainted(false);
        btn.setOpaque(true);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        Color normal = new Color(18, 32, 71);
        Color hover = new Color(25, 45, 90);

        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e){ btn.setBackground(hover); }
            public void mouseExited(MouseEvent e){ btn.setBackground(normal); }
        });

        return btn;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Employee_TimeDashboard().setVisible(true));
    }
}
