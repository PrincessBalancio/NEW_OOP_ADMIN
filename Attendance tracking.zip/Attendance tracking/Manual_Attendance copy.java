package com.example.ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.*;
import java.util.ArrayList;
import java.util.List;

public class Manual_Attendance extends JFrame {

    private JTable tableRequests;
    private JTextPane txtDetails;
    private JPanel bottomPanel;
    private int panelHeight = 0;
    private final int MAX_HEIGHT = 220;
    private Timer slideTimer;

    private List<Object[]> inboxRequests = new ArrayList<>();
    private List<Object[]> approvedRequests = new ArrayList<>();
    private List<Object[]> rejectedRequests = new ArrayList<>();

    private JButton btnInbox, btnApproved, btnRejected;
    private String currentFolder = "Inbox";

    public Manual_Attendance() {
        // ------------ FRAME SETTINGS ------------
        setTitle("Attendance Requests - Admin Dashboard");
        setSize(1200, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setLayout(new BorderLayout());
        getContentPane().setBackground(Color.WHITE);

        // -------------- TOPBAR -----------------
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setPreferredSize(new Dimension(getWidth(), 60));
        topBar.setBackground(Color.WHITE);
        topBar.setBorder(new MatteBorder(0, 0, 1, 0, new Color(220, 220, 220)));
        getContentPane().add(topBar, BorderLayout.NORTH);

        JLabel lblTitle = new JLabel("Attendance Requests");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setBorder(new EmptyBorder(0, 20, 0, 0));
        topBar.add(lblTitle, BorderLayout.WEST);

        // ========== SIDEBAR ==========
        JPanel sidebar = new JPanel();
        sidebar.setPreferredSize(new Dimension(220, getHeight()));
        sidebar.setBackground(new Color(32, 44, 78));
        sidebar.setLayout(new BorderLayout());
        getContentPane().add(sidebar, BorderLayout.WEST);

        // Sidebar top section
        JPanel menuPanel = new JPanel();
        menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));
        menuPanel.setBackground(new Color(47, 63, 96));

        JLabel lblMenu = new JLabel("Folders");
        lblMenu.setForeground(Color.WHITE);
        lblMenu.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblMenu.setBorder(new EmptyBorder(20, 20, 10, 0));
        menuPanel.add(lblMenu);

        // Sidebar buttons
        btnInbox = createSidebarButton("Inbox", true);
        btnApproved = createSidebarButton("Approved", false);
        btnRejected = createSidebarButton("Rejected", false);

        menuPanel.add(btnInbox);
        menuPanel.add(btnApproved);
        menuPanel.add(btnRejected);

        sidebar.add(menuPanel, BorderLayout.NORTH);

        // Sidebar bottom: BACK BUTTON
        JPanel bottomSide = new JPanel(new BorderLayout());
        bottomSide.setBackground(new Color(47, 63, 96));

        JButton btnBack = new JButton("Back");
        btnBack.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btnBack.setFocusPainted(false);
        btnBack.setHorizontalAlignment(SwingConstants.LEFT);
        btnBack.setBorder(new EmptyBorder(10, 20, 10, 10));
        btnBack.setOpaque(true);
        btnBack.setBackground(new Color(47, 63, 96));
        btnBack.setForeground(Color.WHITE);
        btnBack.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btnBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnBack.setBackground(new Color(65, 85, 130));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnBack.setBackground(new Color(47, 63, 96));
            }
        });

        btnBack.addActionListener(e -> dispose());

        bottomSide.add(btnBack, BorderLayout.SOUTH);
        sidebar.add(bottomSide, BorderLayout.SOUTH);

        // ---------- MAIN PANEL ---------
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);
        getContentPane().add(mainPanel, BorderLayout.CENTER);

        JLabel lblInboxHeader = new JLabel("Inbox");
        lblInboxHeader.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblInboxHeader.setBorder(new EmptyBorder(10, 10, 10, 10));
        mainPanel.add(lblInboxHeader, BorderLayout.NORTH);

        tableRequests = new JTable();
        tableRequests.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tableRequests.setRowHeight(30);
        tableRequests.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        tableRequests.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tableRequests.setFillsViewportHeight(true);

        JScrollPane tableScroll = new JScrollPane(tableRequests);
        mainPanel.add(tableScroll, BorderLayout.CENTER);

        // Sliding panel
        initBottomPanel();
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        // ==== Initialize sample data ====
        inboxRequests.add(new Object[]{"Juan Dela Cruz", "2024-06-10", "Clock-in Correction", "Pending"});
        inboxRequests.add(new Object[]{"Maria Santos", "2024-06-11", "Clock-out Correction", "Pending"});
        inboxRequests.add(new Object[]{"Mark Reyes", "2024-06-08", "Absent → Present", "Pending"});

        // ==== Folder button actions ====
        btnInbox.addActionListener(e -> { currentFolder = "Inbox"; loadRequests(); });
        btnApproved.addActionListener(e -> { currentFolder = "Approved"; loadRequests(); });
        btnRejected.addActionListener(e -> { currentFolder = "Rejected"; loadRequests(); });

        loadRequests(); // default view
    }

    // ===== INIT SLIDING PANEL =====
    private void initBottomPanel() {
        bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setPreferredSize(new Dimension(getWidth(), 0));
        bottomPanel.setBorder(new MatteBorder(1, 0, 0, 0, new Color(220, 220, 220)));
        bottomPanel.setBackground(Color.WHITE);

        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(Color.WHITE);

        JButton btnClose = new JButton("×");
        btnClose.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnClose.setFocusPainted(false);
        btnClose.setBorder(null);
        btnClose.setContentAreaFilled(false);
        btnClose.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnClose.addActionListener(e -> slidePanel(false));
        topBar.add(btnClose, BorderLayout.EAST);
        bottomPanel.add(topBar, BorderLayout.NORTH);

        txtDetails = new JTextPane();
        txtDetails.setEditable(false);
        txtDetails.setContentType("text/html");
        txtDetails.setBorder(new EmptyBorder(10, 10, 10, 10));

        JScrollPane detailsScroll = new JScrollPane(txtDetails);
        bottomPanel.add(detailsScroll, BorderLayout.CENTER);

        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        actionPanel.setBackground(Color.WHITE);

        JButton btnApprove = new JButton("Approve");
        stylizeButton(btnApprove);
        btnApprove.addActionListener(e -> moveRequest("Approved"));

        JButton btnReject = new JButton("Reject");
        stylizeButton(btnReject);
        btnReject.addActionListener(e -> moveRequest("Rejected"));

        actionPanel.add(btnApprove);
        actionPanel.add(btnReject);

        bottomPanel.add(actionPanel, BorderLayout.SOUTH);
    }

    // ===== SLIDE PANEL =====
    private void slidePanel(boolean expand) {
        if (slideTimer != null && slideTimer.isRunning()) slideTimer.stop();

        slideTimer = new Timer(5, null);
        slideTimer.addActionListener(e -> {
            if (expand) {
                if (panelHeight < MAX_HEIGHT) {
                    panelHeight += 10;
                    bottomPanel.setPreferredSize(new Dimension(getWidth(), panelHeight));
                    bottomPanel.revalidate();
                } else slideTimer.stop();
            } else {
                if (panelHeight > 0) {
                    panelHeight -= 10;
                    bottomPanel.setPreferredSize(new Dimension(getWidth(), panelHeight));
                    bottomPanel.revalidate();
                } else slideTimer.stop();
            }
        });
        slideTimer.start();
    }

    private JButton createSidebarButton(String text, boolean selected) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", selected ? Font.BOLD : Font.PLAIN, 15));
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);
        btn.setBorder(new EmptyBorder(10, 20, 10, 10));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        btn.setHorizontalAlignment(SwingConstants.LEFT);

        Color normal = new Color(47, 63, 96);
        Color hover = new Color(65, 85, 130);
        Color inboxBabyBlue = new Color(173, 216, 230);
        Color inboxText = new Color(32, 44, 78);

        if (selected && "Inbox".equals(text)) {
            btn.setBackground(inboxBabyBlue);
            btn.setForeground(inboxText);
        } else {
            btn.setBackground(normal);
            btn.setForeground(Color.WHITE);
        }

        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                if (selected && "Inbox".equals(text)) {
                    btn.setBackground(inboxBabyBlue);
                    btn.setForeground(inboxText);
                } else {
                    btn.setBackground(hover);
                    btn.setForeground(Color.WHITE);
                }
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                if (selected && "Inbox".equals(text)) {
                    btn.setBackground(inboxBabyBlue);
                    btn.setForeground(inboxText);
                } else {
                    btn.setBackground(normal);
                    btn.setForeground(Color.WHITE);
                }
            }
        });

        return btn;
    }

    private void stylizeButton(JButton btn) {
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(100, 36));
        btn.setOpaque(true);

        String t = btn.getText() == null ? "" : btn.getText().trim().toLowerCase();

        if ("approve".equals(t)) {
            btn.setBackground(new Color(46, 204, 113));
            btn.setForeground(Color.WHITE);
            btn.setBorder(new LineBorder(new Color(39, 174, 96)));
            btn.addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) { btn.setBackground(new Color(39, 174, 96)); }
                public void mouseExited(MouseEvent e) { btn.setBackground(new Color(46, 204, 113)); }
            });
        } else if ("reject".equals(t)) {
            btn.setBackground(new Color(231, 76, 60));
            btn.setForeground(Color.WHITE);
            btn.setBorder(new LineBorder(new Color(192, 57, 43)));
            btn.addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) { btn.setBackground(new Color(192, 57, 43)); }
                public void mouseExited(MouseEvent e) { btn.setBackground(new Color(231, 76, 60)); }
            });
        }
    }

    private void moveRequest(String action) {
        int row = tableRequests.getSelectedRow();
        if (row < 0) return;

        Object[] request = getCurrentRequests().get(row);

        // If rejected, prompt for reason
        if ("Rejected".equals(action)) {
            String reason = JOptionPane.showInputDialog(this,
                    "Please enter the reason for rejection:", "Reject Request", JOptionPane.PLAIN_MESSAGE);
            if (reason == null || reason.trim().isEmpty()) return; // cancel
            // store reason as 5th element
            if (request.length < 5) {
                Object[] newRequest = new Object[5];
                System.arraycopy(request, 0, newRequest, 0, request.length);
                newRequest[4] = reason;
                request = newRequest;
            } else request[4] = reason;
        }

        // update status
        request[3] = action.equals("Approved") ? "Approved" : "Rejected";

        // move to respective list
        getCurrentRequests().remove(row);
        if (action.equals("Approved")) approvedRequests.add(request);
        else rejectedRequests.add(request);

        loadRequests();
        slidePanel(false);
    }

    private List<Object[]> getCurrentRequests() {
        return switch (currentFolder) {
            case "Inbox" -> inboxRequests;
            case "Approved" -> approvedRequests;
            case "Rejected" -> rejectedRequests;
            default -> inboxRequests;
        };
    }

    private void loadRequests() {
        List<Object[]> list = getCurrentRequests();

        String[] columns = { "Employee", "Date", "Correction Type", "Status" };
        Object[][] data = list.toArray(new Object[0][]);

        tableRequests.setModel(new DefaultTableModel(data, columns) {
            public boolean isCellEditable(int row, int column) { return false; }
        });

        tableRequests.setRowHeight(30);
        tableRequests.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tableRequests.getSelectedRow() >= 0)
                updateRequestDetails();
        });

        tableRequests.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {

                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (isSelected) c.setBackground(new Color(173, 216, 230));
                else c.setBackground(Color.WHITE);

                if (column == 2 && value != null) {
                    String type = value.toString();
                    switch (type) {
                        case "Clock-in Correction": c.setForeground(new Color(0, 102, 204)); break;
                        case "Clock-out Correction": c.setForeground(new Color(0, 153, 51)); break;
                        case "Absent → Present": c.setForeground(new Color(204, 102, 0)); break;
                        default: c.setForeground(Color.BLACK);
                    }
                } else c.setForeground(Color.BLACK);
                return c;
            }
        });

        txtDetails.setText("<html>Select a request from the table above to view details.<br><br>" +
            "All correction requests include:<br>- Original Time Record<br>- Requested New Time<br>" +
            "- Required Justification<br>- Attachments (if any)</html>");
    }

    private void updateRequestDetails() {
        int selectedRow = tableRequests.getSelectedRow();
        if (selectedRow >= 0) {
            Object[] row = getCurrentRequests().get(selectedRow);
            String employee = row[0].toString();
            String date = row[1].toString();
            String type = row[2].toString();
            String status = row[3].toString();
            String reason = row.length > 4 ? row[4].toString() : "N/A";

            String statusColor = switch (status) {
                case "Approved" -> "green";
                case "Rejected" -> "red";
                default -> "orange";
            };

            String detailsHtml =
                "<html><b>Employee:</b> " + employee + "<br>" +
                "<b>Date:</b> " + date + "<br>" +
                "<b>Correction Type:</b> " + type + "<br>" +
                "<b>Status:</b> <span style='color:" + statusColor + "'>" + status + "</span><br><br>" +
                "<b>Original Time Record:</b> 08:00 - 17:00<br>" +
                "<b>Requested Correction:</b> 09:00 - 17:00<br>" +
                "<b>Justification:</b> Employee was late due to traffic.<br>" +
                "<b>Rejection Reason:</b> " + reason + "<br></html>";

            txtDetails.setText(detailsHtml);
            slidePanel(true);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Manual_Attendance().setVisible(true));
    }
}
